package myLibrary.DataStructures.Tree;

public class BST {

	// Create node: see Node.java
	
	// Insert new node in BST - you can use recursive or iterative method
	public Node insert(int data, Node root) 
	{
        if (root == null) {
            return new Node(data);
        }

        if (data < root.data) {
            root.left = insert(data, root.left);
        } else if (data > root.data) {
            root.right = insert(data, root.right);
        }

        return root;
	}
	
	// Inorder traversal - recursive OR iterative
	public void inOrder(Node node) 
	{
        if (node == null) {
            return;
        }

        inOrder(node.left);
        System.out.print(node.data + " ");
        inOrder(node.right);

	}

	// Preorder traversal - recursive OR iterative
	public void preOrder(Node node) 
	{
        if (node == null) {
            return;
        }

        System.out.print(node.data + " ");
        preOrder(node.left);
        preOrder(node.right);

	}
	
	// Postorder traversal - recursive OR iterative
	public void postOrder(Node node) 
	{
        if (node == null) {
            return;
        }

        postOrder(node.left);
        postOrder(node.right);
        System.out.print(node.data + " ");
	}
	
	// Breadth first traversal - recursive OR iterative
	public void breadthFirstTraversal(Node root) 
	{
        if (root == null) {
            return;
        }

        int capacity = 100;
        CustomQueue queue = new CustomQueue(capacity);
        queue.enqueue(root);

        while (!queue.isEmpty()) {
            Node current = queue.dequeue();
            System.out.print(current.data + " ");

            if (current.left != null) {
                queue.enqueue(current.left);
            }
            if (current.right != null) {
                queue.enqueue(current.right);
            }
        }
	}
	
	// Search in BST
	public Node searchBinarySearchTree(Node node, int key)
	{
        if (node == null || node.data == key) {
            return node;
        }

        if (key < node.data) {
            return searchBinarySearchTree(node.left, key);
        } else {
            return searchBinarySearchTree(node.right, key);
        }
	}
	
	// Delete from BST
	public Node deleteNode(Node root, int key) 
	{
        if (root == null) {
            return null;
        }

        if (key < root.data) {
            root.left = deleteNode(root.left, key);
        } else if (key > root.data) {
            root.right = deleteNode(root.right, key);
        } else {
            if (root.left == null) {
                return root.right;
            } else if (root.right == null) {
                return root.left;
            }

            root.data = minValue(root.right);
            root.right = deleteNode(root.right, root.data);
        }

        return root;
	}
	
	// Add any other parts needed
	
    private int minValue(Node node) {
        int minValue = node.data;
        while (node.left != null) {
            minValue = node.left.data;
            node = node.left;
        }
        return minValue;
    }
    
    // Custom Queue implementation using a linked list
    private static class CustomQueue {
        private Node[] queueArray;
        private int front;
        private int rear;
        private int capacity;
        private int size;

        public CustomQueue(int capacity) {
            this.queueArray = new Node[capacity];
            this.front = 0;
            this.rear = -1;
            this.capacity = capacity;
            this.size = 0;
        }

        public void enqueue(Node node) {
            if (isFull()) {
                System.out.println("Queue is Full - Overflow");
                return;
            }
            rear = (rear + 1) % capacity;
            queueArray[rear] = node;
            size++;
        }

        public Node dequeue() {
            if (isEmpty()) {
                System.out.println("Queue is Empty - Underflow");
                return null;
            }
            Node node = queueArray[front];
            front = (front + 1) % capacity;
            size--;
            return node;
        }

        public boolean isEmpty() {
            return size == 0;
        }

        public boolean isFull() {
            return size == capacity;
        }
    }
}
