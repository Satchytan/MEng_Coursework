package myLibrary.DataStructures.Tree;

public class Node 
{
	// Define BST node
    int data;
    Node left;
    Node right;

    public Node(int data) {
        this.data = data;
        this.left = null;
        this.right = null;
    }
}
