package myLibrary.GraphAlgo;

public class Dijkstra {
    private int numVertices;

	// Apply Dijkstras algorithm
	public void Dijkstra_Algo(int[][] graph, int source) 
	{
		  this.numVertices = graph.length;

	        int[] distance = new int[numVertices];
	        boolean[] shortestPathTreeSet = new boolean[numVertices];

	        for (int i = 0; i < numVertices; i++) {
	            distance[i] = Integer.MAX_VALUE;
	            shortestPathTreeSet[i] = false;
	        }

	        distance[source] = 0;

	        for (int count = 0; count < numVertices - 1; count++) {
	            int u = minDistance(distance, shortestPathTreeSet);
	            shortestPathTreeSet[u] = true;

	            for (int v = 0; v < numVertices; v++) {
	                if (!shortestPathTreeSet[v] && graph[u][v] != 0 && distance[u] != Integer.MAX_VALUE
	                        && distance[u] + graph[u][v] < distance[v]) {
	                    distance[v] = distance[u] + graph[u][v];
	                }
	            }
	        }

	        for (int i = 0; i < numVertices; i++) {
	        	if (distance[i] == Integer.MAX_VALUE) {
	                System.out.println("NO PATH  from " + source + " to " + i);
	            } else {
	            System.out.println("Distance from " + source + " to " + i + " is " + distance[i]);
	            }
	        }
	    }

	    private int minDistance(int[] distance, boolean[] shortestPathTreeSet) {
	        int min = Integer.MAX_VALUE;
	        int minIndex = -1;

	        for (int v = 0; v < numVertices; v++) {
	            if (!shortestPathTreeSet[v] && distance[v] <= min) {
	                min = distance[v];
	                minIndex = v;
	            }
	        }

	        return minIndex;
	}
	  
	// Add any other parts needed
}
