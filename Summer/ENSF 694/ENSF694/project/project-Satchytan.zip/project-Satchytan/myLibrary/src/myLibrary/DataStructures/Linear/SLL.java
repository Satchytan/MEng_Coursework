package myLibrary.DataStructures.Linear;

public class SLL {

	// Define node
	 private Node head;

	    private static class Node {
	        int data;
	        Node next;

	        Node(int data) {
	            this.data = data;
	            this.next = null;
	        }
	    }

	    // Constructor to initialize the linked list
	    public SLL() {
	        this.head = null;
	    }
	    
	// Add node to SLL
    public void addNode(int data) 
    {   
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }   
    
    // Search node in SLL
    public int searchNode(int key)
    {
    	Node current = head;
        int index = 0;
        while (current != null) {
            if (current.data == key) {
                return index;
            }
            current = current.next;
            index++;
        }
        return -1;
    }
    
    // Delete node form SLL
    public void deleteNode(int key) 
    {
    	System.out.println("\nDeleting Node with value " + key);
    	
    	if (head == null) {
            return;
        }

        if (head.data == key) {
            head = head.next;
            return;
        }

        Node current = head;
        while (current.next != null) {
            if (current.next.data == key) {
                current.next = current.next.next;
                return;
            }
            current = current.next;
        }
    }
    
    // Display SLL
    public void display() 
    {
    	System.out.println("\nCurrent nodes of the singly linked list:");
    	
    	Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    } 
    
    // Add any other parts needed

}
