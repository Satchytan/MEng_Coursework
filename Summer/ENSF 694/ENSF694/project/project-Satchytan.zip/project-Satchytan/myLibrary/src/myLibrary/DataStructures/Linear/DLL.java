package myLibrary.DataStructures.Linear;

public class DLL {

	// Define node

    private Node head;

    private static class Node {
        int data;
		Node prev;
        Node next;

        Node(int data) {
            this.data = data;
            this.prev = null;
            this.next = null;
        }
    }

    // Constructor to initialize the doubly linked list
    public DLL() {
        this.head = null;
    }
	
	// Add node
    public void addNode(int data) 
    {    
    	Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
            newNode.prev = current;
        }
    }   
    
    // Search node
    public int searchNode(int key)
    {
    	Node current = head;
        int index = 0;
        while (current != null) {
            if (current.data == key) {
                return index;
            }
            current = current.next;
            index++;
        }
        return -1;
    }
    
    // Delete node
    public void deleteNode(int key) 
    {
    	System.out.println("\nDeleting Node with value " + key);
    	
        if (head == null) {
            return;
        }

        if (head.data == key) {
            head = head.next;
            if (head != null) {
                head.prev = null;
            }
            return;
        }

        Node current = head;
        while (current.next != null) {
            if (current.next.data == key) {
                current.next = current.next.next;
                if (current.next != null) {
                    current.next.prev = current;
                }
                return;
            }
            current = current.next;
        }
    }
    
    // Display the DLL
    public void display() 
    {        
    	System.out.println("\nCurrent nodes of the doubly linked list:");

    	Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    } 
    
    // Add any other parts needed
}
