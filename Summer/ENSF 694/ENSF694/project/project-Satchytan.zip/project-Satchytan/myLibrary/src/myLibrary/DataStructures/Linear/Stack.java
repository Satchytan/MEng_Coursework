package myLibrary.DataStructures.Linear;

public class Stack {
	
    private int[] stack;
    private int top;
    private int capacity;

    // Constructor to initialize the stack
    public Stack(int capacity) {
        this.stack = new int[capacity];
        this.top = -1;
        this.capacity = capacity;
    }
	
	public void push(int data){ // push method 
		if(top == capacity-1) {
			System.out.println("Stack is Full - Overflow");
			return;
		}else{
			top = top + 1;
			stack[top] = data;
			//System.out.println(data +" Pushed into Stack");
		}
	}

	public int pop(){ // pop method }
		int data;
		if(top < 0) {
			System.out.println("Stack is Empty - Underflow");
			return -1;
		}else{
			data = stack[top];
			stack[top] = 0; // to remove the data from array
			top = top - 1;
		}
		//System.out.print("Popped from Stack ");
		return data;
		
	}

	public void display(){ // display method }
		for(int i = 0; i <= stack.length - 1 ; i++) {
			System.out.print(stack[i] + " ");
		}
		
	}
}
