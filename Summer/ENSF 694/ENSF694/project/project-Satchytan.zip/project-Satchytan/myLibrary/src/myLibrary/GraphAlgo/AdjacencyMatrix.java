package myLibrary.GraphAlgo;

public class AdjacencyMatrix {
	
	// Define adjacency matrix
    private int numVertices;
    private int[][] adjMatrix;

    public AdjacencyMatrix(int numVertices) {
        this.numVertices = numVertices;
        adjMatrix = new int[numVertices][numVertices];
    }

	// Add new edges
    public void addEdge(int source, int destination, int cost) 
    {
        adjMatrix[source][destination] = cost;
        adjMatrix[destination][source] = cost; // Assuming an undirected graph
    }
    
    // return adjacency matrix
    public int[][] getAdjacencyMatrix() 
    {
        return adjMatrix;
    }

    // Display adjacency matrix
    public void displayAdjacencyMatrix() 
    {	        
        for (int i = 0; i < numVertices; i++) {
        	System.out.print("Node " + i +": ");
            for (int j = 0; j < numVertices; j++) {
                System.out.print(adjMatrix[i][j] + " ");
            }
            System.out.println();
        }
    }
    
    // Add any other parts needed
    
}

