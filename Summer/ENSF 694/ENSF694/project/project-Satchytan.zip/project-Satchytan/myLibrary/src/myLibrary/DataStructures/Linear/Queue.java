package myLibrary.DataStructures.Linear;

public class Queue {
	
    private int[] queue;
    private int head;
    private int tail;
    private int capacity;

    // Constructor to initialize the queue
    public Queue(int capacity) {
        this.queue = new int[capacity];
        this.head = 0;
        this.tail = -1;
        this.capacity = capacity;
    }
    
	public void enqueue(int data){ // enqueue method }
		if(tail == capacity-1){
			System.out.println("Queue is Full - Overflow");
			return;
		}else{
			if(head == -1 && tail == -1) {
					head = 0;
					tail = 0;
			}else{
				tail = tail + 1;
			}
			queue[tail] = data;
		}
	}
	public int dequeue(){ // dequeue method }
		int data;
		if(head < 0 || head > tail) {
			System.out.println("Queue is Empty - Underflow");
			return -1;
		}else{
			data = queue[head];
			queue[head] = 0; // to remove the data from array
			head = head + 1;
		}
		//System.out.print("Dequeued from Queue ");
		return data;
	}
	
	public void display(){ // display method }
		for(int i = 0; i <= queue.length - 1 ; i++) {
			System.out.print(queue[i] + " ");
		}
	}
}